Hi user, welcome to Infinity X.

When you install Infinity X, you must whitelist it in your antivitus (Its not malware etc.! Its an injector.)
How to deactivate Windows-Defender:

1. Press Windows and look for Windows Security and click it
2. Go to Viruses and threat protection and go to Manage Settings
3. And Turn off Real-time protection

Lets have fun with Infinity X.

-------------------------IMPORTANT-------------------------
       The injector is from EasyExploits not from me! 
-------------------------IMPORTANT-------------------------